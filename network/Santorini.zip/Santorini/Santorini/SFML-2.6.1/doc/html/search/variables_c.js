var searchData=
[
  ['name_0',['name',['../structsf_1_1Joystick_1_1Identification.html#a135a9a3a4dc11c2b5cde51159b4d136d',1,'sf::Joystick::Identification']]],
  ['none_1',['None',['../classsf_1_1IpAddress.html#a4619b4abbe3c8fef056e7299db967404',1,'sf::IpAddress']]]
];
