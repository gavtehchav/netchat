var searchData=
[
  ['vendorid_0',['vendorId',['../structsf_1_1Joystick_1_1Identification.html#a827caf37a56492e3430e5ca6b15b5e9f',1,'sf::Joystick::Identification']]]
];
